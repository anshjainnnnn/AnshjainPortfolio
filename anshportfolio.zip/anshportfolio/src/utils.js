export const getImageUrl = (path) => `../assests/${path}`;
